from django.apps import AppConfig


class RecetasConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "applications.recetas"
    verbose_name = "Recetas MealDB"
